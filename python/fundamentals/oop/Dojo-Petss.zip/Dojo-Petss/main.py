from pet import Dog, Cat
from ninja import Ninja

# Create an instance of a Dog
dog = Dog("Buddy", "dog", ["sit", "roll over"])

# Create an instance of a Cat
cat = Cat("Whiskers", "cat", ["jump", "scratch"])

# Create an instance of a Ninja with the dog instance
ninja1 = Ninja("John", "Doe", "treats", "pet food", dog)
ninja1.walk()  # Output: "Woof!"

# Create another instance of a Ninja with the cat instance
ninja2 = Ninja("Jane", "Smith", "treats", "pet food", cat)
ninja2.walk()  # Output: "Meow!"